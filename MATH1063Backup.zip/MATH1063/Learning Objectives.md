## The definite integral

- [x] (DI1) Compute signed areas under curves with simple geometries.
- [x] (DI2) Use properties of integration to compute integrals from other integrals.
- [x] (DI3) Set up a Riemann Sum to estimate an integral.
- [x] (DI4) Compute the error of Riemann sums of monotonic functions.
- [x] (DI5) Apply the Fundamental Theorem of Calculus to compute definite integrals.
- [x] (DI6) Sketch areas corresponding to integrals.
- [x] (DI7) Apply the Fundamental Theorem of Calculus to functions defined by integrals, for example using the chain rule.
- [x] (DI8) Derive properties of logarithms from the integral definition.
- [x] (DI9) Compute the distance travelled and the displacement of a particle in 1D.
- [x] (DI10) Compute and integral as a limit of Reimann Approximations.
- [x] (DI11) Use the u-substitition method of integration.

## Taylor Series and improper integrals

- [x] (TS1) Derive the geometric series.
- [x] (TS2) Compute a degree n Taylor polynomial expanded at a point a, or obtain power series expansions from repeated differentiation.
- [x] (TS3) Compute error bounds of Taylor approximations from bounds on higher derivatives.
- [x] (TS4) Sketch a series as an infinite histogram.
- [x] (TS5) Sketch areas corresponding to improper integrals.
- [x] (TS6) Evaluate simple improper integrals.
- [x] (TS7) Apply comparison tests with integrals or series to establish convergence or divergence.
- [ ] Obtain power series expansions from the geometric series.
- [ ] Derive geometric series for shifts and translations of $f(x) = \frac{1}{1-x}$ .
- [ ] Obtain power series expansions of composites of basic functions.
- [ ] Apply the ratio or root test to determine radii of convergence.
- [ ] Obtain power series expansions by term-by-term differentiation or integration, being mindful of constants.

## Methods of integration

- [ ] Apply the following methods to find antiderivatives
	- [ ] u-substitution.
	- [ ] integration by parts.
		- [ ] Multi-step integration by parts
	- [ ] trigonometric substitution.
	- [ ] partial fractions.
		- [ ] Denominators factors into linear factors.
		- [ ] General case.
- [ ] Change bounds of integration in definite integrals.
- [ ] Derive and apply reduction formulas.
- [ ] Compute more complicated indefinite integrals.

## Applications of integration

- [ ] The integral as an infinite summation
	- [ ] Compute areas of regions bounded by graphs of functions.
	- [ ] Set up integrals to compute the lengths of curves.
	- [ ] Compute volumes with sketches and integrals using:
		- [ ] Slices
		- [ ] Washers
		- [ ] Shells
	- [ ] Compute centers of mass
	- [ ] Compute the work done by a variable force moving in 1D.
- [ ] Set up and solve differential equations using:
	- [ ] Separation of variables
	- [ ] Integrating factors
	- [ ] Power series
- [ ] Probability
	- [ ] Normalize functions to make them into probability distribution functions.
	- [ ] Compute means and variance.
