The $r$-th element in the $n$-th row of Pascal's Triangle is given by,
$$
\begin{pmatrix}
n \\
r 
\end{pmatrix} = \frac{n!}{r!(n-r)!}
$$
We take the alternate elements of Pascal's triangle around our specified center. So, we get,
$$
\begin{pmatrix}
n-1 \\
r-1
\end{pmatrix} \cdot 
\begin{pmatrix}
n \\
r + 1
\end{pmatrix} \cdot
\begin{pmatrix}
n+1 \\
r
\end{pmatrix}
$$
and,

$$
\begin{pmatrix}
n-1 \\
r
\end{pmatrix} \cdot 
\begin{pmatrix}
n+1 \\
r+1
\end{pmatrix} \cdot
\begin{pmatrix}
n \\
r-1
\end{pmatrix}
$$
Multiplying the first set,
$$
= \frac{(n-1)!}{(r-1)!(n-r)!} \cdot \frac{n!}{(r+1)!(n-r-1)!} \cdot \frac{(n+1)!}{r!(n+1-r)!}
$$
