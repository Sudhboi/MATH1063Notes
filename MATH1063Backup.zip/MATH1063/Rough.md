
$$
\frac{\pi}{4} = 1-\frac{1}{3} + \frac{1}{5} - \frac{1}{7} +\dots = \sum_{n=0}^{\infty} \frac{(-1)^{n}}{2n+1}
$$
$$
\implies \pi = 4\sum_{n=0}^{\infty} \frac{(-1)^{n}}{2n+1}
$$
$$
\frac{\pi}{6} = \arcsin\left( \frac{1}{2} \right) = \sum_{n=0}^{\infty} \frac{(-1)^{n}}{2n+1} \begin{pmatrix}
-\frac{1}{2} \\
n
\end{pmatrix}
\left( \frac{1}{2} \right)^{2n+1}
$$
$$
\implies \pi = 6\sum_{n=0}^{\infty} \frac{(-1)^{n}}{2n+1} \begin{pmatrix}
-\frac{1}{2} \\
n
\end{pmatrix}
\left( \frac{1}{2} \right)^{2n+1}
$$
$$
\begin{pmatrix}
r \\
n
\end{pmatrix}
= \frac{r(r-1)(r-2)\dots(r-(n-2))(r-(n-1))}{n!}=\frac{\prod_{i=0}^{n-1} (r-i)}{n!}
$$
$$
|\pi-P(N)| < a_{n} = \frac{1}{2N+1}
$$